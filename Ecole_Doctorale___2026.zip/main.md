# Introduction {#sec:intro}

The remainder of this paper is organized as follows.
Section [2](#sec:method){reference-type="ref" reference="sec:method"}
describes the dataset and methodology.
Section [3](#sec:results){reference-type="ref" reference="sec:results"}
reports the experimental results.
Section [4](#sec:discussion){reference-type="ref"
reference="sec:discussion"} discusses the findings and their
limitations, and Section [5](#sec:conclusion){reference-type="ref"
reference="sec:conclusion"} concludes the paper.

# Data and Methodology {#sec:method}

## Dataset {#subsec:dataset}

## Preprocessing {#subsec:preprocessing}

## Regression model(s) {#subsec:models}

$$\begin{equation}
\label{eq:linreg}
\hat{y} = \beta_0 + \sum_{j=1}^{p} \beta_j x_j + \varepsilon ,
\end{equation}$$ where $\hat{y}$ is the predicted target, $x_j$ are the
$p$ predictors, $\beta_j$ the estimated coefficients and $\varepsilon$
the error term.

## Evaluation protocol {#subsec:protocol}

$$\begin{align}
\text{R}^2   &= 1 - \frac{\sum_i (y_i-\hat{y}_i)^2}{\sum_i (y_i-\bar{y})^2}, &
\text{MAE}  &= \frac{1}{n}\sum_{i=1}^{n}\lvert y_i-\hat{y}_i\rvert, \\
\text{MSE}  &= \frac{1}{n}\sum_{i=1}^{n}(y_i-\hat{y}_i)^2, &
\text{RMSE} &= \sqrt{\text{MSE}} .
\end{align}$$

# Results {#sec:results}

## Predictive performance

::: tabular
l S S S S Model & $\text{R}^2$ & MAE & MSE & RMSE\
Model A & 0.0000 & 0.0000 & 0.0000 & 0.0000\
Model B & 0.0000 & 0.0000 & 0.0000 & 0.0000\
:::

As reported in
Table [\[tab:performance\]](#tab:performance){reference-type="ref"
reference="tab:performance"}, the best-performing model is

## Estimated coefficients

::: tabular
l S S S Predictor & Coefficient & Std. error & $p$-value\
Intercept & 0.0000 & 0.0000 & 0.0000\
Feature 1 & 0.0000 & 0.0000 & 0.0000\
Feature 2 & 0.0000 & 0.0000 & 0.0000\
:::

## Diagnostic plots

<figure id="fig:pred_vs_actual" data-latex-placement="ht">
<span class="image placeholder"
data-original-image-src="fig_predicted_vs_actual.png"
data-original-image-title="" width="70%"></span>
<figcaption>Predicted versus actual values for the &lt;model name&gt;
model on the test set.</figcaption>
</figure>

<figure id="fig:residuals" data-latex-placement="ht">
<span class="image placeholder"
data-original-image-src="fig_residuals.png" data-original-image-title=""
width="70%"></span>
<figcaption>Residual plot of the &lt;model name&gt; model. A random
scatter around zero indicates that the model assumptions are reasonably
satisfied.</figcaption>
</figure>

Figure [1](#fig:pred_vs_actual){reference-type="ref"
reference="fig:pred_vs_actual"} shows ...
Figure [2](#fig:residuals){reference-type="ref"
reference="fig:residuals"} indicates ...

# Discussion {#sec:discussion}

# Conclusion and future work {#sec:conclusion}
